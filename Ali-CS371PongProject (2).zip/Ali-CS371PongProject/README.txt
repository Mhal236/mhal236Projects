Contact Info
============

Group Members & Email Addresses:

    Muhammad Ali | mhal236@uky.edu

Versioning
==========

Github Link: 

General Info
============
To run the project, follow these steps:

1. Run the server component first (pongServer.py) to start hosting the game. (If not working use VScode)
2. Run the client component (pongClient.py) to join the game. Enter the server's IP address and port. (If not running use VScode)

The game should start, and you can play Pong against another player over the network.

Install Instructions
====================

Run the following line to install the required libraries for this project:

`pip3 install -r requirements.txt`

Known Bugs
==========
- No gradual disconnect feature.
- Sometimes an issue when not running through VSCODE
- Sometimes if no audio device is connected an error occurs


