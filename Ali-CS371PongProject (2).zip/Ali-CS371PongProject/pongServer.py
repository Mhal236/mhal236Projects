# =================================================================================================
# Contributing Authors:	    Muhammad Ali
# Email Addresses:          mhal236@uky.edu
# Date:                     11/16/2023
# Purpose:                  Establishes a socket connection and listens for incoming client connections.
# Misc:                     Last bug: no audio device is connected an error occurs

# =================================================================================================
# Use this file to write your server logic
# You will need to support at least two clients
# You will need to keep track of where on the screen (x,y coordinates) each paddle is, the score 
# for each player and where the ball is, and relay that to each client
# I suggest you use the sync variable in pongClient.py to determine how out of sync your two
# clients are and take actions to resync the games

import socket
import threading
import pickle
import socket
import threading

from assets.code import game_logic
from assets.code.player import Player
from assets.code.ball import Ball
import pygame

# Define server host and port
host = "localhost"
port = 8000

# Create a socket and bind it to the specified host and port
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind((host, port))

# Initialize player and ball objects using Player and Ball classes
players = {
    'player_1': {
        'player': Player(50, 250, (55, 155, 255))
    },
    'player_2': {
        'player': Player(550, 250, (255, 155, 55))
    }
}
ball = Ball(295, 295, (155, 155, 155))
clock = pygame.time.Clock()

# Maintain a list of connected clients i.e player 1 & 2
clients = []

# Start listening for incoming connections
server.listen()
print('Server started. Waiting for connections...')

# Initialize variables for managing players and ball
current_player_id = 1
ball_running = False

# Function to update the ball's position
def handle_ball():
    while True:
        ball.update([players['player_1']['player'], players['player_2']['player']])
        clock.tick(60)

# Function to handle communication with clients 
def handle_client(client, id):
    global current_player_id

     # Send the current player's information to the client
    client.send(pickle.dumps(players[f'player_{id}']['player']))

    while True:
        try:
            # Receive the updated player information from the client
            player = pickle.loads(client.recv(1024))
            players[f'player_{id}']['player'] = player

            # Send game state information to the clients
            if id == 1:
                client.send(pickle.dumps([players['player_2']['player'], ball, game_logic.player_1_score, game_logic.player_2_score]))

            elif id == 2:
                client.send(pickle.dumps([players['player_1']['player'], ball, game_logic.player_1_score, game_logic.player_2_score]))
            
            # Check for game-over conditions
            if game_logic.player_1_score == 5:
                client.send(pickle.dumps(f'Player 1 won the game!'))

            elif game_logic.player_2_score == 5:
                client.send(pickle.dumps(f'Player 2 won the game!'))

        except:
             # Handle disconnection and update game state
            ball.renew()
            print(f'player_{id} disconnected')

            if id == 1:
                current_player_id = 1
                if len(clients) == 1:
                    other_client = clients[0]
                    other_client.send(pickle.dumps(f'Player {id} won the game!'))

            elif id == 2:
                current_player_id = 2
                if len(clients) == 1:
                    other_client = clients[0]
                    other_client.send(pickle.dumps(f'Player {id} won the game!'))
# Main loop to accept incoming connections
while True:
    game_logic.renew()
    client, address = server.accept()

    # Add the new client to the list and print connection information
    clients.append(client)
    print(f'player {current_player_id} connected from {address}')

    # Start a new thread to handle communication with the client
    threading.Thread(target=handle_client, args=(client, current_player_id)).start()

    # Start a new thread to handle the ball movement if player 2 connects
    if current_player_id == 2 and not ball_running:
        threading.Thread(target=handle_ball).start()
        ball_running = True

    # Increment the player ID for the next connection
    current_player_id += 1
