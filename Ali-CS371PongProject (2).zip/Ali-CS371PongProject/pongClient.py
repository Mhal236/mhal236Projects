# =================================================================================================
# Contributing Authors:	    Muhammad Ali
# Email Addresses:          mhal236@uky.edu
# Date:                     11/16/2023
# Purpose:                  Connects user to the server using socket communication.
# Misc:                     Last bug: Unstable connection when having firewall up on server end computer
# =================================================================================================
import pickle  # Serialization and deserialization of Python objects for network communication
import pygame  # Library for handling graphics, events, and rendering of the game
import tkinter as tk  # GUI toolkit for creating the game's user interface
import sys  # Provides system-specific parameters and functions (not used explicitly in this code)
import socket  # Enables network communication between the server and clients

# This is the main game loop.  For the most part, you will not need to modify this.  The sections
# where you should add to the code are marked.  Feel free to change any part of this project
# to suit your needs.
def playGame(screenWidth: int, screenHeight: int, playerPaddle: str, client: socket.socket) -> None:
   
    """
    Main game loop that handles gameplay and rendering.

    Parameters:
    - screenWidth, screenHeight: Dimensions of the game screen
    - playerPaddle: Indicates the side on which the player is positioned (left/right)
    - client: Socket for communication with the server
    """
    # Pygame inits
    # pygame.mixer.pre_init(44100, -16, 2, 2048)
    pygame.init()
    pygame.mixer.init()

    # Create the game window
    screen = pygame.display.set_mode((640, 480))
    pygame.display.set_caption("My Game")
    
    # Constants
    WHITE = (255, 255, 255)

    # clock = pygame.time.Clock()

    # Screen and player setup
    screen_width = screenWidth
    screen_height = screenHeight
    screen = pygame.display.set_mode((screen_width, screen_height))
    clock = pygame.time.Clock()
    player = get_player(client)
    screen_center_x = screen_width / 2
    screen_center_y = screen_height / 2


    # Main game loop
    running = True
    while running:
        for event in pygame.event.get():
        
             if event.type == pygame.QUIT:
                  running = False
        # Clear the screen
        screen.fill((0, 0, 0))
        # centerLine = []
        # for i in range(0, screenHeight, 10):
        #     centerLine.append(pygame.Rect((screenWidth / 2) - 5, i, 5, 5))
        # for i in centerLine:
        #     pygame.draw.rect(screen, WHITE, i)
        # # Update the screen


        # Get game data from the server
        data = get_data(client, player)
        font = pygame.font.Font(None, 36)

        # Check if the game has ended
        if type(data) is str:
            # Display the win message
           
            font = pygame.font.Font(None, 36)
            message = font.render(f"{data}", True, (255, 255, 255))

            text_width, text_height = font.size(data)  # Get text size
            text_x = (screen_width - text_width) // 2    # Calculate X position
            text_y = (screen_height - text_height) // 2  # Calculate Y position

            screen.blit(message, (text_x, text_y))
            player.update(screen)
            pygame.display.update()

            break

        else:
            # Update game state information
            opponent = data[0]
            ball = data[1]
            player_1_score, player_2_score = data[2], data[3]


            # Display player scores
            player_1_score_text = font.render(f"Player 1: {player_1_score}", True, (255, 255, 255))
            player_2_score_text = font.render(f"Player 2: {player_2_score}", True, (255, 255, 255))
            screen.blit(player_1_score_text, (20, 20))
            screen.blit(player_2_score_text, (screen_width - 150, 20))

            # Update player, opponent, and ball positions
            player.update(screen)
            opponent.draw(screen)
            ball.draw(screen)
            pygame.display.update()
            clock.tick(60)


# This is where you will connect to the server to get the info required to call the game loop.  Mainly
# the screen width, height and player paddle (either "left" or "right")
# If you want to hard code the screen's dimensions into the code, that's fine, but you will need to know
# which client is which

def get_player(client):
    """
    Retrieves player information from the server using socket communication.

    Parameter:
    - client: Socket connection with the server

    Returns:
    - Player data received from the server
    """
    
    return pickle.loads(client.recv(1024))


def get_data(client, player):
    """
    Sends player data to the server and receives game state data.

    Parameters:
    - client: Socket connection with the server
    - player: Player data

    Returns:
    - Game state information received from the server
    """
    client.send(pickle.dumps(player))
    return pickle.loads(client.recv(1024))

# Establishes a connection with the server to initiate the game.
def joinServer(ip: str, port: int, errorLabel: tk.Label, app: tk.Tk) -> None:
    """
    Establishes a connection with the server to initiate the game.

    Parameters:
    - ip: Server IP address
    - port: Port used by the server for communication
    - errorLabel: Tkinter label widget for displaying messages to the user
    - app: Tkinter window object
    """
    print(port ,ip)
    # Create a socket and connect to the server
    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client.connect((ip, port))

    # Purpose:      This method is fired when the join button is clicked
    # Arguments:
    # ip            A string holding the IP address of the server
    # port          A string holding the port the server is using
    # errorLabel    A tk label widget, modify it's text to display messages to the user (example below)
    # app           The tk window object, needed to kill the window

    # Create a socket and connect to the server
    # You don't have to use SOCK_STREAM, use what you think is best
    # client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    # Get the required information from your server (screen width, height & player paddle, "left or "right)

    # If you have messages you'd like to show the user use the errorLabel widget like so
    # errorLabel.config(text=f"Some update text. You input: IP: {ip}, Port: {port}")
    # You may or may not need to call this, depending on how many times you update the label
    # errorLabel.update()

    # Close this window and start the game with the info passed to you from the server
    app.withdraw()     # Hides the window (we'll kill it later)
    playGame(640, 600, "left", client)  # User will be either left or right paddle
    # app.quit()         # Kills the window


# This displays the opening screen, you don't need to edit this (but may if you like)
def startScreen():
    """
    Displays the initial screen for the user to enter server IP and port.
    """
    app = tk.Tk()
    app.title("Server Info")

    image = tk.PhotoImage(file="./assets/images/logo.png")

    titleLabel = tk.Label(image=image)
    titleLabel.grid(column=0, row=0, columnspan=2)

    ipLabel = tk.Label(text="Server IP:")
    ipLabel.grid(column=0, row=1, sticky="W", padx=8)

    ipEntry = tk.Entry(app)
    ipEntry.grid(column=1, row=1)

    portLabel = tk.Label(text="Server Port:")
    portLabel.grid(column=0, row=2, sticky="W", padx=8)

    portEntry = tk.Entry(app)
    portEntry.grid(column=1, row=2)

    errorLabel = tk.Label(text="")
    errorLabel.grid(column=0, row=4, columnspan=2)

    joinButton = tk.Button(text="Join",
                           command=lambda: joinServer(ipEntry.get(), int(portEntry.get()), errorLabel, app))
    joinButton.grid(column=0, row=3, columnspan=2)

    app.mainloop()


if __name__ == "__main__":
    pygame.init()
    # Display the start screen and initiate the game
    startScreen()
    # Quit pygame after the game is finished
    pygame.quit()

    # Uncomment the line below if you want to play the game without a server to see how it should work
    # the startScreen() function should call playGame with the arguments given to it by the server this is
    # here for demo purposes only
    # playGame(640, 480,"left",socket.socket(socket.AF_INET, socket.SOCK_STREAM))
