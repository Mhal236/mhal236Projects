import pygame

class Player:
    """
    Represents a player entity in the game.

    Attributes:
    - x (int): X-coordinate of the player's paddle.
    - y (int): Y-coordinate of the player's paddle.
    - width (int): Width of the player's paddle.
    - height (int): Height of the player's paddle.
    - rect (pygame.Rect): Rectangle object representing the player's paddle.
    - velocity (int): Speed at which the player's paddle moves.
    - color (tuple): RGB color tuple representing the player's paddle's color.
    - score (int): Player's score.

    Methods:
    - movement(): Handles the movement of the player's paddle based on key presses.
    - draw(screen): Draws the player's paddle on the provided screen.
    - update(screen): Updates the player's paddle movement and draws it on the screen.
    """
    def __init__(self, x, y, color):
        """
        Initializes the Player object with the provided coordinates and color.

        Args:
        - x (int): X-coordinate of the player's paddle.
        - y (int): Y-coordinate of the player's paddle.
        - color (tuple): RGB color tuple representing the player's paddle's color.
        """
        self.x = x
        self.y = y
        self.width = 10
        self.height = 100
        self.rect = pygame.Rect(self.x, self.y, self.width, self.height)
        self.velocity = 5
        self.color = color
        self.score = 0

# Author: <Who wrote this method>
# Purpose: <What should this method do>
# Pre: <What preconditions does this method expect to be true? 
# Post: <What postconditions are true after this method is called? Ex. This method
    def movement(self):
        """Handles the movement of the player's paddle based on keyboard input."""
        keys = pygame.key.get_pressed()

        # Restrict paddle movement within screen boundaries
        if self.rect.top <= 0:
            self.rect.top = 0
        elif self.rect.bottom >= 600:
            self.rect.bottom = 600

        # Detect keyboard input for paddle movement
        if keys[pygame.K_w]:
            self.rect.y -= self.velocity
        if keys[pygame.K_s]:
            self.rect.y += self.velocity

    def draw(self, screen):
        """Draws the player's paddle on the provided screen."""
        pygame.draw.rect(screen, self.color, self.rect)

    def update(self, screen):
        """Updates the player's paddle movement and draws it on the screen."""
        self.movement()
        self.draw(screen)
