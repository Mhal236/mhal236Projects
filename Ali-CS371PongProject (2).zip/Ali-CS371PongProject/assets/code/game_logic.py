# game_logic.py

# Global Variables
global player_1_score, player_2_score

# Initialize player scores
player_1_score = 0
player_2_score = 0

def update_scores(player):
    """
    Updates the scores for Player 1 or Player 2 based on the provided player number.
    Args:
    - player (int): Indicates the player whose score needs to be updated (1 for Player 1, 2 for Player 2).
    """
    global player_1_score, player_2_score

    if player == 1:
        player_1_score += 1
    elif player == 2:
        player_2_score += 1

def renew():
    """
    Resets the player scores to zero.
    Resets the global variables player_1_score and player_2_score back to 0.
    Used when starting a new game or when a game needs to be reset.
    """
    global player_1_score, player_2_score

    player_1_score = 0
    player_2_score = 0
