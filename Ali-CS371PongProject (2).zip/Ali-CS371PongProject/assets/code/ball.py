import pygame
from time import sleep
from .game_logic import update_scores, player_1_score, player_2_score
from .utilities import play_sound_bounce, play_sound_point

class Ball:
    """
    Represents the Ball entity in the game.
    Attributes:
    - x : X-coordinate of the ball.
    - y : Y-coordinate of the ball.
    - width : Width of the ball.
    - height : Height of the ball.
    - rect : Rectangle object representing the ball.
    - velocity : Velocity vector of the ball.
    - color : RGB color tuple representing the ball's color.
    Methods:
    - movement(): Handles the movement of the ball.
    - collisions(players): Manages the collisions of the ball with players' paddles.
    - draw(screen): Draws the ball on the provided screen.
    - update(players): Updates the ball's movement and collisions.
    - renew(): Resets the ball's position and direction.
    """
    def __init__(self, x, y, color):
        self.x = x
        self.y = y
        self.width = 10
        self.height = 10
        self.rect = pygame.Rect(self.x, self.y, self.width, self.height)
        self.velocity = pygame.Vector2(3, 3)
        self.color = color

    def movement(self):
        """Handles the movement of the ball based on its velocity."""
        self.rect.x += self.velocity.x
        self.rect.y += self.velocity.y

        # Handle ball movement when reaching screen boundaries
        if self.rect.top <= 0 or self.rect.bottom >= 600:
            self.velocity.y *= -1

    def collisions(self, players):
        """
        Args:
        - players (list): List containing Player objects representing the players' paddles.
        """
        for player in players:
            if self.rect.colliderect(player.rect):
                self.velocity.x *= -1
                play_sound_bounce()
                # Update scores based on player colors

        # Reset ball position and update scores when it reaches left/right boundary
        if self.rect.left <= 0:
            self.rect.x, self.rect.y = 295, 295
            self.velocity.x *= -1
            play_sound_point()
            update_scores(2)

        if self.rect.right >= 600:
            self.rect.x, self.rect.y = 295, 295
            self.velocity.x *= -1
            play_sound_point()
            update_scores(1)

    def draw(self, screen):
       # Draws the ball on the provided screen
        pygame.draw.rect(screen, self.color, self.rect)

    def update(self, players):
       # Updates the ball's movement and collisions
        self.movement()
        self.collisions(players)

    def renew(self):
        # Resets the ball's position and direction
        self.rect.x, self.rect.y = 295, 295
        self.velocity.x *= -1
