# pygame.init()

# pygame.mixer.pre_init(44100, -16, 2, 2048)
import pygame
pygame.mixer.init()
pygame.mixer.pre_init(44100, -16, 2, 2048)
pointSound = pygame.mixer.Sound("./assets/sounds/point.wav")
bounceSound = pygame.mixer.Sound("./assets/sounds/bounce.wav")


def play_sound_point():
    pointSound.play()

def play_sound_bounce():
    bounceSound.play()


def get_score_font():
    return pygame.font.Font("./assets/fonts/pong-score.ttf", 32)

def get_win_font():
    return  pygame.font.Font("./assets/fonts/visitor.ttf", 48)    


