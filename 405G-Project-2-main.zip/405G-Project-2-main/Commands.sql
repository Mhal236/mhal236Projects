/*
These commands will build the whole database from deliverable 1. It will have both tables and all the addresses and receipts added
Just copy + paste into the linux VM's mysql command line interpreter by taking the following steps
	1. Make sure you're connected to either the campus Wi-Fi or to the GlobalProtect VPN
	2. Open a terminal (command prompt on Windows for example)
	3. Enter the command `ssh <your linkblue ID>@coreopsis.cs.uky.edu`
	4. Enter your password
	5. Enter the command `mysql -h mysql.cs.uky.edu -p -u <your linkblue ID>`
	6. Enter the command `use <your linkblue ID>;`
	7. Now you're ready to copy + paste the following SQL
*/

-- Creates the buyers/sellers table
CREATE TABLE `buyers_sellers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(45) DEFAULT NULL,
  `last_name` varchar(45) DEFAULT NULL,
  `business_name` varchar(45) DEFAULT NULL,
  `address` varchar(45) DEFAULT NULL,
  `contact_pref` varchar(12) DEFAULT NULL,
  `city` varchar(45) DEFAULT NULL,
  `state` varchar(45) DEFAULT NULL,
  `zipcode` int(11) DEFAULT NULL,
  `phone_number` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `duplicate` boolean NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4;

-- Creates the receipts table
CREATE TABLE `receipts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `buyer_id` int(11) DEFAULT NULL,
  `seller_id` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `total_sale_price` float DEFAULT NULL,
  `num_items_sold` int(11) DEFAULT NULL,
  `item_type` varchar(45) DEFAULT NULL,
  `photo` blob,
  PRIMARY KEY (`id`),
  KEY `buyer` (`buyer_id`),
  KEY `seller` (`seller_id`),
  CONSTRAINT `buyer` FOREIGN KEY (`buyer_id`) REFERENCES `buyers_sellers` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `seller` FOREIGN KEY (`seller_id`) REFERENCES `buyers_sellers` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4;

-- Inserts all the buyers + sellers necessary into the buyers/sellers table
INSERT INTO `buyers_sellers` VALUES
	-- TEAM 2
  (1,'Ray','Hyatt',NULL,'300 Rose Street Room 102 Hardymon Building',NULL,'Lexington','Kentucky',40506,'859-569-7328',NULL,1),
  (2,'Ray','Hyatt',NULL,'301 Hilltop Avenue, Room 102',NULL,'Lexington','Kentucky',40506,'859-704-0673',NULL,1),
  (3,'John','Wick',NULL,'82 Beaver St Room 1301',NULL,'New York','New York',10005,'212-689-2205',NULL,1),
  (4,'Tony','Stark',NULL,'200 Park Avenue Penthouse',NULL,'New York','New York',10001,'212-260-8011',NULL,1),
  (5,'Stephen','Strange',NULL,'117A Bleecker Street',NULL,'New York','New York',10001,'212-450-9980',NULL,1),
  (6,'Bob','Smith',NULL,'200 Park Avenue Apartment 221',NULL,'New York','New York',10001,'212-283-0790',NULL,1),
  (7,'Bowman','Wildcat',NULL,'#1 Avenue of Champions',NULL,'Lexington','Kentucky',40506,'859-545-3186',NULL,1),
  (8,'Bob','Smith',NULL,'200 Park Avenue',NULL,'Lexington','Kentucky',40507,'859-807-3422',NULL,1),
  (9,'Bob','Porter','Intech','1 Dead End Row Room 200',NULL,'Dallas','Texas',12347,'214-490-6476',NULL,1),
  (10,'Bob','Sydell','Intech','1 Dead End Row Room 200',NULL,'Dallas','Texas',12347,'214-716-2266',NULL,1),
  (11,NULL,NULL,'Honey Joe\'s','5 Broad St Unit 2B',NULL,'Stamford','Connecticut',6901,'203-732-7524',NULL,0),
  (12,'Alex','Savinsky',NULL,'112 Revonah Ave',NULL,'Stamford','Connecticut',6905,'203-821-8582',NULL,0),
  (13,NULL,NULL,'Lowe\'s','2300 Grey Lag Way',NULL,'Lexington','Kentucky',40509,'859-868-5437',NULL,0),
  (14,'Richard','Dunn',NULL,'662 Bluegrass Park Dr',NULL,'Lexington','Kentucky',40508,'859-366-9462',NULL,0),
  (15,NULL,NULL,'Jersey Mike\'s','2200 War Admiral Way',NULL,'Lexington','Kentucky',40509,'859-407-4090',NULL,0),
  (16,'Anthony','Wilson',NULL,'1153 Mt Rushmore Way',NULL,'Lexington','Kentucky',40515,'859-485-8917',NULL,0),
  (17,NULL,NULL,'Cook Out','855 S Broadway',NULL,'Lexington','Kentucky',40504,'859-403-5888',NULL,0),
  (18,'Louis','Miller',NULL,'219 Londonderry Dr',NULL,'Lexington','Kentucky',40504,'859-343-6973',NULL,0),
  (19,NULL,NULL,'Metro-North Railroad','420 Lexington Avenue 5th Floor',NULL,'New York','New York',10170,'212-208-2054',NULL,0),
  (20,'Justin','Barlow',NULL,'122 E 93rd St',NULL,'New York','New York',10128,'212-637-7995',NULL,0),
  (21,NULL,NULL,'Party City','2172 Sir Barton Way',NULL,'Lexington','Kentucky',40509,'859-710-2968',NULL,0),
  (22,'James','Anderson',NULL,'2480 Paris Pike',NULL,'Lexington','Kentucky',40511,'859-939-4559',NULL,0),
  (23,NULL,NULL,'McDonald\'s','2271 Elkhorn Road',NULL,'Lexington','Kentucky',40505,'859-963-6796',NULL,0),
  (24,'Adam','Harris',NULL,'2703 Barbados Ln',NULL,'Lexington','Kentucky',40509,'859-371-2882',NULL,0),
  (25,NULL,NULL,'Walmart','2350 Grey Lag Way',NULL,'Lexington','Kentucky',40509,'859-566-5493',NULL,0),
  (26,'Charles','Lee',NULL,'501 Ridge Rd',NULL,'Lexington','Kentucky',40503,'859-316-0466',NULL,0),
  (27,NULL,NULL,'Costco','1500 Fitzgerald Court',NULL,'Lexington','Kentucky',40509,'859-452-2932',NULL,0),
  (28,'Daniel','Johnson',NULL,'3601 Brookewind Way',NULL,'Lexington','Kentucky',40515,'859-785-9278',NULL,0),
  (29,NULL,NULL,'Culver\'s','2161 Paul Jones Way',NULL,'Lexington','Kentucky',40509,'859-985-5145',NULL,0),
  (30,'Sam','Davis',NULL,'1325 Wakehurst Ct',NULL,'Lexington','Kentucky',40509,'859-574-8865',NULL,0),
  (31,NULL,NULL,'Meijer','2155 Paul Jones Way, Suite 100',NULL,'Lexington','Kentucky',40509,'859-666-2995',NULL,0),
  (32,'Lucas','Campbell',NULL,'408 Lenney Ct',NULL,'Lexington','Kentucky',40517,'859-535-7635',NULL,0),
  (33,NULL,NULL,'Olive Garden','3094 Helmsdale Place',NULL,'Lexington','Kentucky',40509,'859-996-1054',NULL,0),
  (34,'Ethan','Cooper',NULL,'325 Silverbell Trace',NULL,'Lexington','Kentucky',40514,'859-474-3924',NULL,0),
  (35,NULL,NULL,'The UPS Store','1890 Star Shoot Pkwy #170',NULL,'Lexington','Kentucky',40509,'859-920-9194',NULL,0),
  (36,'Henry','Williams',NULL,'2152 Carolina Ln',NULL,'Lexington','Kentucky',40513,'859-733-7354',NULL,0),
  (37,NULL,NULL,'Lilli & Loo','785 Lexington Avenue',NULL,'New York','New York',10065,'212-600-9065',NULL,0),
  (38,'Ella','Brown',NULL,'2222 Frederick Douglass Blvd',NULL,'New York','New York',10026,'212-589-5828',NULL,0),
  (39,NULL,NULL,'Wendy\'s','2296 Thunderstick Dr',NULL,'Lexington','Kentucky',40505,'859-922-1143',NULL,0),
  (40,'Liam','Clark',NULL,'620 Cooper Dr',NULL,'Lexington','Kentucky',40502,'859-440-1904',NULL,0),
	-- TEAM 1
  (41,'James','Hill',NULL,'685 S Limestone Apt 203',NULL,'Lexington','Kentucky','40508','859-656-7612',NULL,0),
  (42,'Andrew','Montgomery',NULL,'629 Nakomi Drive',NULL,'Lexington','Kentucky','40503','555-123-4567',NULL,0),
  (43,'Victor','Cerzyk',NULL,'1617 Kensington Way',NULL,'Lexington','Kentucky','40513','555-987-6543',NULL,0),
  (44,'Dean','Ween',NULL,'3824 Kittiwake Dr',NULL,'Lexington','Kentucky','40517','555-789-0123',NULL,0),
  (45,'Mickey','Melchiondo',NULL,'103 Edison Drive',NULL,'Lexington','Kentucky','40503','555-234-5678',NULL,0),
  (46,'Aaron','Freeman Sr.',NULL,'2029 Oleander Drive',NULL,'Lexington','Kentucky','40504','555-876-5332',NULL,0),
  (47,'Milton','Plumbottom',NULL,'3527 Brookview Dr.',NULL,'Lexington','Kentucky','40517','555-345-6689',NULL,0),
  (48,'Po','Wei',NULL,'100 W 57th St #12E',NULL,'New York','New York','10019','555-765-4121',NULL,0),
  (49,'Frankie','Bauls',NULL,'70 Oceana Drive W #1D',NULL,'Brooklyn','New York','11235','555-456-7890',NULL,0),
  (50,'Jerry','Garcia',NULL,'215 E 24th St APT 110',NULL,'New York','New York','10010','555-654-3210',NULL,0),
  (51,'Nate','Newton',NULL,'155 E 79th St #9',NULL,'New York','New York','10075','555-210-9676',NULL,0),
  (52,'Chris','Barland',NULL,'2239 Troy Ave APT 6C',NULL,'Brooklyn','New York','11234','555-543-2129',NULL,0),
  (53,'Harry','DuBois',NULL,'6108 Abrams Rd APT 101',NULL,'Dallas','Texas','75231','555-890-1234',NULL,0),
  (54,'Jimmy','Wilson',NULL,'6600 Eastridge Dr APT 117',NULL,'Dallas','Texas','75231','555-321-0987',NULL,0),
  (55,'Annie','Hall',NULL,'3030 McKinney Ave APT 1104',NULL,'Dallas','Texas','75204','555-678-9012',NULL,0),
  (56,NULL,NULL,'Wildcat Pantry','440 Hilltop Ave',NULL,'Lexington','Kentucky','40508','555-432-1198',NULL,0),
  (57,NULL,NULL,'Awesome Inc Business','348 E Main St',NULL,'Lexington','Kentucky','40507','555-109-8765',NULL,0),
  (58,NULL,NULL,'Urban Outfitters','Victorian Sq, 401 W Main St',NULL,'Lexington','Kentucky','40507','555-876-5532',NULL,0),
  (59,NULL,NULL,'Pies & Pints','401 W Main St Suite 106',NULL,'Lexington','Kentucky','40507','555-567-4221',NULL,0),
  (60,NULL,NULL,'Pasta Garage Italian Café','962 Delaware Ave',NULL,'Lexington','Kentucky','40505','555-234-9776',NULL,0),
  (61,NULL,NULL,'Sorella Gelateria','591 W Short St',NULL,'Lexington','Kentucky','40507','555-345-2119',NULL,0),
  (62,NULL,NULL,'Agave & Rye','123 N Broadway',NULL,'Lexington','Kentucky','40507','555-678-5432',NULL,0),
  (63,NULL,NULL,'Chaotic Good','545 South Broadway Suite 160',NULL,'Lexington','Kentucky','40508','555-987-1298',NULL,0),
  (64,NULL,NULL,'Crank & Boom Craft Ice Cream','1210 Manchester St',NULL,'Lexington','Kentucky','40504','555-876-4421',NULL,0),
  (65,NULL,NULL,'Kroger','704 Euclid Avenue',NULL,'Lexington','Kentucky','40502','555-123-2111',NULL,0),
  (66,NULL,NULL,'Target','500 S Upper Street STE 110',NULL,'Lexington','Kentucky','40508','555-543-6789',NULL,0),
  (67,NULL,NULL,'Fox Pest Control','2532 Regency Rd Suite #105',NULL,'Lexington','Kentucky','40503','555-890-4321',NULL,0),
  (68,NULL,NULL,'Amazon Corporate HeadQuarters','410 Terry Ave N',NULL,'Seattle','Washington','98109','555-321-9876',NULL,0),
  (69,NULL,NULL,'PacSun','3401 Nicholasville Rd',NULL,'Lexington','Kentucky','40503','555-678-2109',NULL,0),
  (70,NULL,NULL,'Walmart','500 W New Circle Rd',NULL,'Lexington','Kentucky','40511','555-432-1098',NULL,0),
	-- TEAM 18
  (71,'John','Doe',NULL,'455 10th Ave',NULL,'New York','New York','10018','718-889-0558',NULL,0),
  (72,'Jessica','Robinson',NULL,'490 Second Avenue, Apt 09A',NULL,'New York','New York','10016','646-460-2689',NULL,0),
  (73,'Antony','Miller',NULL,'100 W 31st St',NULL,'New York','New York','10001','646-423-9978',NULL,0),
  (74,'Malcolm','McMillan',NULL,'600 W 58th St',NULL,'New York','New York','10019','212-793-5196',NULL,0),
  (75,'Christa','George',NULL,'95 Wall St',NULL,'New York','New York','10005','656-430-1230',NULL,0),
  (76,'Cassie','Stevens',NULL,'329 S. Martin Luther King Blvd, Boyd Hall',NULL,'Lexington','Kentucky','40526','606-813-1678',NULL,0),
  (77,'Dawson','Jones',NULL,'6403 Del Norte Ln',NULL,'Dallas','Texas','75225','606-813-3268',NULL,0),
  (78,'Hope','Smith',NULL,'3608 Hopetown Rd',NULL,'Dallas','Texas','75229','606-813-1535',NULL,0),
  (79,'Allie','Phillips',NULL,'2209 Sweetberry Ct',NULL,'Lexington','Kentucky','40513','606-231-0417',NULL,0),
  (80,'Loch','Ness',NULL,'558 Jonelle Ave',NULL,'Dallas','Texas','75217','859-447-7062',NULL,0),
  (81,'Rack','Room Shoes',NULL,'3401 Nicholasville Rd, Spc D-406 Fayette Mall',NULL,'Lexington','Kentucky','40503','855-466-7467',NULL,0),
  (82,NULL,NULL,'H&M','3401 Nicholasville Rd, Fayette Mall',NULL,'Lexington','Kentucky','40503','855-466-7467',NULL,0),
  (83,NULL,NULL,'FYE','3401 Nicholasville Rd, Fayette Mall',NULL,'Lexington','Kentucky','40503','859-273-1685',NULL,0),
  (84,NULL,NULL,'Auntie Anne\'s','3615 Nicholasville Rd, Fayette Mall',NULL,'Lexington','Kentucky','40503',NULL,NULL,0),
  (85,NULL,NULL,'Pediatric and Adolescent','3050 Harrodsburg Rd Ste 100',NULL,'Lexington','Kentucky','40503','859-277-6102',NULL,0),
  (86,NULL,NULL,'The UPS Store','838 E High St',NULL,'Lexington','Kentucky','40502','859-268-6231',NULL,0),
  (87,NULL,NULL,'Target','131 West Reynolds Rd',NULL,'Lexington','Kentucky','40503','859-273-9403',NULL,0),
  (88,NULL,NULL,'University of Kentucky Bookstore','160 Avenue of Champions',NULL,'Lexington','Kentucky','40526','859-257-0236',NULL,0),
  (89,NULL,NULL,'Buffalo Wild Wings','1080 S Broadway Ste 104',NULL,'Lexington','Kentucky','40504','859-233-2999',NULL,0),
  (90,NULL,NULL,'Best Buy','3220 Nicholasville Rd Ste 170',NULL,'Lexington','Kentucky','40503','859-272-0024',NULL,0),
  (91,NULL,NULL,'Nintendo Store','10 Rockefeller Plaza',NULL,'New York','New York','10020','646-459-0800',NULL,0),
  (92,NULL,NULL,'Black Iron Burger','245 W 38th St',NULL,'New York','New York','10018','646-476-3116',NULL,0),
  (93,NULL,NULL,'Texas Instruments Incorporated - Headquarters','12500 TI Blvd',NULL,'Dallas','Texas','75243','855-226-3113',NULL,0),
  (94,NULL,NULL,'Chewy','1950 N Stemmons Fwy',NULL,'Dallas','Texas','75207','800-672-4399',NULL,0),
  (95,NULL,NULL,'Froggie\'s 5 & 10 Toy Store','3207 Knox St',NULL,'Dallas','Texas','75205','214-522-5867',NULL,0),
  (96,NULL,NULL,'Camp','9830 N Central Expy',NULL,'Dallas','Texas','75231','214-612-0451',NULL,0),
  (97,NULL,NULL,'Wild Bill\'s Western Store','311 N Market St Ste 101',NULL,'Dallas','Texas','75202','214-954-1050',NULL,0),
  (98,NULL,NULL,'Rezdora','27 E 20th St',NULL,'New York','New York','10003','646-692-9090',NULL,0),
  (99,NULL,NULL,'Bengal Tiger','58 W 56th St',NULL,'New York','New York','10019','212-265-2703',NULL,0),
  (100,NULL,NULL,'Apple Fifth Avenue','767 5th Ave',NULL,'New York','New York','10153','212-336-1440',NULL,0);

-- Inserts all the receipts necessary into the receipts table
INSERT INTO `receipts` VALUES
  (1,11,12,'2023-09-23',11.49,2,'Food',NULL),
  (2,13,14,'2023-02-09',223.87,40,'Home Goods',NULL),
  (3,15,16,'2023-09-13',27.75,4,'Food',NULL),
  (4,17,18,'2023-09-04',9.32,1,'Food',NULL),
  (5,19,20,'2023-09-25',26.75,1,'Train Ticket',NULL),
  (6,21,22,'2023-09-16',28.62,21,'Home Goods',NULL),
  (7,23,24,'2023-09-27',9.21,1,'Food',NULL),
  (8,25,26,'2023-09-14',19.95,5,'Home Goods',NULL),
  (9,27,28,'2023-09-19',120.79,3,'Home Goods',NULL),
  (10,29,30,'2023-09-01',8.68,1,'Food',NULL),
  (11,31,32,'2023-09-19',2.89,1,'Food',NULL),
  (12,33,34,'2023-09-12',46.72,3,'Food',NULL),
  (13,35,36,'2023-09-19',26.42,1,'Mailing',NULL),
  (14,37,38,'2023-09-23',83.62,4,'Food',NULL),
  (15,39,40,'2023-09-09',9.85,1,'Food',NULL),
  (16,69,47,'2023-03-20',266.33,8,NULL,NULL),
  (17,59,44,'2023-01-25',34.21,2,NULL,NULL),
  (18,62,42,'2023-04-30',24.22,1,NULL,NULL),
  (19,70,41,'2022-09-27',131.43,6,NULL,NULL),
  (20,68,48,'2020-04-16',18.19,2,NULL,NULL),
  (21,63,53,'2023-08-28',34.01,3,NULL,NULL),
  (22,57,50,'2023-09-11',45.63,2,NULL,NULL),
  (23,65,54,'2023-10-02',13.17,1,NULL,NULL),
  (24,61,52,'2023-09-02',8.96,1,NULL,NULL),
  (25,56,43,'2023-08-14',56.77,3,NULL,NULL),
  (26,66,45,'2023-09-16',15.10,6,NULL,NULL),
  (27,64,51,'2023-09-15',5.28,1,NULL,NULL),
  (28,60,49,'2023-09-16',10.18,1,NULL,NULL),
  (29,67,55,'2023-09-30',21.19,3,NULL,NULL),
  (30,58,46,'2023-10-01',23.72,8,NULL,NULL),
  (31,79,81,'2023-09-16',41.11,2,'Shoes',NULL),
  (32,76,82,'2023-09-16',37.81,3,'Clothes',NULL),
  (33,76,83,'2023-09-16',37.81,3,'Clothes',NULL),
  (34,76,84,'2023-09-16',10.63,2,'Pretzels',NULL),
  (35,61,85,'2023-09-29',26.00,1,'Copay',NULL),
  (36,69,86,'2023-10-11',0.00,4,'Item Return',NULL),
  (37,68,87,'2023-09-16',7.83,1,'Snacks',NULL),
  (38,76,88,'2023-09-08',53.92,7,'Books',NULL),
  (39,67,89,'2023-06-08',24.35,1,'Wings',NULL),
  (40,74,90,'2023-09-15',790.23,4,'Xbox + Accessories',NULL),
  (41,64,91,'2023-08-12',103.21,2,'Video Games',NULL),
  (42,75,92,'2023-06-30',29.10,2,'Burger',NULL),
  (43,78,95,'2023-07-03',120.83,10,'Toys',NULL),
  (44,71,98,'2023-05-30',31.24,2,'Italian Food',NULL),
  (45,73,99,'2023-08-11',63.12,4,'Indian Food',NULL);

-- Edits contact pref's for all buyers_sellers
UPDATE buyers_sellers
SET 
    contact_pref = 'DNC'
WHERE
    last_name = 'Hyatt';
UPDATE buyers_sellers
SET 
    contact_pref = 'ROBOCALL'
WHERE
    last_name = 'Wick';   
UPDATE buyers_sellers
SET 
    contact_pref = 'TEXT'
WHERE
    first_name = 'Bob';
UPDATE buyers_sellers
SET 
    contact_pref = 'ALL & FAX'
WHERE
    last_name = 'Stark';
UPDATE buyers_sellers
SET 
    contact_pref = 'ROBOCALL'
WHERE
    id > 10 && id < 22;
UPDATE buyers_sellers
SET 
    contact_pref = 'ROBOCALL'
WHERE
    id > 21 && id < 44;
UPDATE buyers_sellers
SET 
    contact_pref = 'PHONE'
WHERE
    id = 45;
UPDATE buyers_sellers
SET 
    contact_pref = 'MAIL'
WHERE
    id = 46 || id = 84;

UPDATE buyers_sellers
SET 
    contact_pref = 'TEXT'
WHERE
    id > 46 && id < 59;
UPDATE buyers_sellers
SET 
    contact_pref = 'MAIL'
WHERE
    id > 59 && id < 69;
UPDATE buyers_sellers
SET 
    contact_pref = 'PHONE'
WHERE
    id > 68 && id < 84;
UPDATE buyers_sellers
SET 
    contact_pref = 'PHONE'
WHERE
    id = 85;
UPDATE buyers_sellers
SET 
    contact_pref = 'ALL'
WHERE
    id > 85 && id < 90;
UPDATE buyers_sellers
SET 
    contact_pref = 'PHONE'
WHERE
    id > 89;



    



