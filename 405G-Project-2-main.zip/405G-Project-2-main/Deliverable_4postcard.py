import mysql.connector

db_conn = mysql.connector.connect(
  host="mysql.cs.uky.edu",
  user="",
  password="",
  database=""
)

cursor = db_conn.cursor()

# Execute quries
cursor.execute("SELECT email FROM buyers_sellers where duplicate = 1")
emails = cursor.fetchall()
cursor.execute("SELECT first_name FROM buyers_sellers where duplicate = 1")
first_names = cursor.fetchall()
cursor.execute("SELECT last_name FROM buyers_sellers where duplicate = 1")
last_names = cursor.fetchall()
cursor.execute("SELECT business_name FROM buyers_sellers where duplicate = 1")
business_names = cursor.fetchall()
cursor.execute("SELECT address FROM buyers_sellers where duplicate = 1")
addresses = cursor.fetchall()
cursor.execute("SELECT city FROM buyers_sellers where duplicate = 1")
cities = cursor.fetchall()
cursor.execute("SELECT state FROM buyers_sellers where duplicate = 1")
states = cursor.fetchall()
cursor.execute("SELECT zipcode FROM buyers_sellers where duplicate = 1")
zipcodes = cursor.fetchall()

for i in range(len(emails)):
    print(f"""
---------------------------------
{emails[i][0]}
{first_names[i][0]} {last_names[i][0]}
{addresses[i][0]}
{cities[i][0]}, {states[i][0]}, {zipcodes[i][0]}

----------------------------------
{first_names[i][0]} {last_names[i][0]} {business_names[i][0]}
It is great to meet you again! Your favorite food delivery family is growing, looks like you have already met some of our now expanded family. We want you to know that you will now get the same great service from our newly added drivers!

Looking forward to serving you again!
---------------------------------
        \t""")
