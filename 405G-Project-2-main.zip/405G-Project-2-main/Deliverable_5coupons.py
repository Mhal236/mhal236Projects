import mysql.connector
import random

db_conn = mysql.connector.connect(
  host="mysql.cs.uky.edu",
  user="",
  password="",
  database=""
)

cursor = db_conn.cursor()

# Execute queries
cursor.execute("SELECT email, phone_number, contact_pref, first_name, last_name, business_name, address, city, state, zipcode FROM buyers_sellers where duplicate = 1")
results = cursor.fetchall()

# Sample data representing pre-existing customers
customers = [
    {"email": email, "phone_number": phone_number, "contact_pref": contact_pref, "first_name": first_name, "last_name": last_name,
     "business_name": business_name, "address": address, "city": city, "state": state, "zipcode": zipcode}
    for email, phone_number, contact_pref, first_name, last_name, business_name, address, city, state, zipcode in results
]

# Function to generate a 25% coupon code
def generate_coupon():
    return ''.join(random.choices('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', k=8))

# Function to generate output based on contact preferences
def generate_output(customer):
    contact_pref = customer["contact_pref"].split()
    business_name = customer['business_name'] + ", " if customer['business_name'] else ""
    full_name = f"{customer['first_name']} {customer['last_name']}"
    output = ""
    if "EMAIL" in contact_pref:
        output += f"EMAIL: {business_name}{full_name}; {customer['email']}; 25% Coupon Code\n"
    if "TEXT" in contact_pref:
        output += f"TEXT: {business_name}{full_name}; {customer['phone_number']}; 25% Coupon Code\n"
    if "ROBOCALL" in contact_pref:
        output += f"ROBOCALL: {business_name}{full_name}; {customer['phone_number']}; 25% Coupon Code\n"
    if "PHONE" in contact_pref:
        output += f"PHONE: {business_name}{full_name}; {customer['phone_number']}; 25% Coupon Code\n"
    if "FAX" in contact_pref:
        output += f"FAX: {business_name}{full_name}; {customer['phone_number']}; 25% Coupon Code\n"
    if "DNC" in contact_pref:
        output += f"DNC: {full_name}\n"
    if "MAIL" in contact_pref:
        output += f"MAIL: {business_name}{full_name}; {customer['address']}; 25% Coupon Code\n"
    if "ALL" in contact_pref:
        # Include all preferences
        output += f"ALL: {business_name}{full_name}; {customer['email']}, {customer['phone_number']}, {customer['address']}; 25% Coupon Code\n"
    return output

# Main program
for customer in customers:
    if customer["contact_pref"]:
        output = generate_output(customer)
        print(output)
