-- MySQL dump 10.13  Distrib 8.0.35, for Linux (x86_64)
--
-- Host: mysql    Database: jba231
-- ------------------------------------------------------
-- Server version	5.5.5-10.1.48-MariaDB-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `jba231`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `jba231` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;

USE `jba231`;

--
-- Table structure for table `buyers_sellers`
--

DROP TABLE IF EXISTS `buyers_sellers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `buyers_sellers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(45) DEFAULT NULL,
  `last_name` varchar(45) DEFAULT NULL,
  `business_name` varchar(45) DEFAULT NULL,
  `address` varchar(45) DEFAULT NULL,
  `city` varchar(45) DEFAULT NULL,
  `state` varchar(45) DEFAULT NULL,
  `zipcode` int(11) DEFAULT NULL,
  `phone_number` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `buyers_sellers`
--

LOCK TABLES `buyers_sellers` WRITE;
/*!40000 ALTER TABLE `buyers_sellers` DISABLE KEYS */;
INSERT INTO `buyers_sellers` VALUES
	-- TEAM 2
  (1,'Ray','Hyatt',NULL,'300 Rose Street Room 102 Hardymon Building','Lexington','Kentucky',40506,'859-569-7328'),
  (2,'Ray','Hyatt',NULL,'301 Hilltop Avenue, Room 102','Lexington','Kentucky',40506,'859-704-0673'),
  (3,'John','Wick',NULL,'82 Beaver St Room 1301','New York','New York',10005,'212-689-2205'),
  (4,'Tony','Stark',NULL,'200 Park Avenue Penthouse','New York','New York',10001,'212-260-8011'),
  (5,'Stephen','Strange',NULL,'117A Bleecker Street','New York','New York',10001,'212-450-9980'),
  (6,'Bob','Smith',NULL,'200 Park Avenue Apartment 221','New York','New York',10001,'212-283-0790'),
  (7,'Bowman','Wildcat',NULL,'#1 Avenue of Champions','Lexington','Kentucky',40506,'859-545-3186'),
  (8,'Bob','Smith',NULL,'200 Park Avenue','Lexington','Kentucky',40507,'859-807-3422'),
  (9,'Bob','Porter','Intech','1 Dead End Row Room 200','Dallas','Texas',12347,'214-490-6476'),
  (10,'Bob','Sydell','Intech','1 Dead End Row Room 200','Dallas','Texas',12347,'214-716-2266'),
  (11,NULL,NULL,'Honey Joe\'s','5 Broad St Unit 2B','Stamford','Connecticut',6901,'203-732-7524'),
  (12,'Alex','Savinsky',NULL,'112 Revonah Ave','Stamford','Connecticut',6905,'203-821-8582'),
  (13,NULL,NULL,'Lowe\'s','2300 Grey Lag Way','Lexington','Kentucky',40509,'859-868-5437'),
  (14,'Richard','Dunn',NULL,'662 Bluegrass Park Dr','Lexington','Kentucky',40508,'859-366-9462'),
  (15,NULL,NULL,'Jersey Mike\'s','2200 War Admiral Way','Lexington','Kentucky',40509,'859-407-4090'),
  (16,'Anthony','Wilson',NULL,'1153 Mt Rushmore Way','Lexington','Kentucky',40515,'859-485-8917'),
  (17,NULL,NULL,'Cook Out','855 S Broadway','Lexington','Kentucky',40504,'859-403-5888'),
  (18,'Louis','Miller',NULL,'219 Londonderry Dr','Lexington','Kentucky',40504,'859-343-6973'),
  (19,NULL,NULL,'Metro-North Railroad','420 Lexington Avenue 5th Floor','New York','New York',10170,'212-208-2054'),
  (20,'Justin','Barlow',NULL,'122 E 93rd St','New York','New York',10128,'212-637-7995'),
  (21,NULL,NULL,'Party City','2172 Sir Barton Way','Lexington','Kentucky',40509,'859-710-2968'),
  (22,'James','Anderson',NULL,'2480 Paris Pike','Lexington','Kentucky',40511,'859-939-4559'),
  (23,NULL,NULL,'McDonald\'s','2271 Elkhorn Road','Lexington','Kentucky',40505,'859-963-6796'),
  (24,'Adam','Harris',NULL,'2703 Barbados Ln','Lexington','Kentucky',40509,'859-371-2882'),
  (25,NULL,NULL,'Walmart','2350 Grey Lag Way','Lexington','Kentucky',40509,'859-566-5493'),
  (26,'Charles','Lee',NULL,'501 Ridge Rd','Lexington','Kentucky',40503,'859-316-0466'),
  (27,NULL,NULL,'Costco','1500 Fitzgerald Court','Lexington','Kentucky',40509,'859-452-2932'),
  (28,'Daniel','Johnson',NULL,'3601 Brookewind Way','Lexington','Kentucky',40515,'859-785-9278'),
  (29,NULL,NULL,'Culver\'s','2161 Paul Jones Way','Lexington','Kentucky',40509,'859-985-5145'),
  (30,'Sam','Davis',NULL,'1325 Wakehurst Ct','Lexington','Kentucky',40509,'859-574-8865'),
  (31,NULL,NULL,'Meijer','2155 Paul Jones Way, Suite 100','Lexington','Kentucky',40509,'859-666-2995'),
  (32,'Lucas','Campbell',NULL,'408 Lenney Ct','Lexington','Kentucky',40517,'859-535-7635'),
  (33,NULL,NULL,'Olive Garden','3094 Helmsdale Place','Lexington','Kentucky',40509,'859-996-1054'),
  (34,'Ethan','Cooper',NULL,'325 Silverbell Trace','Lexington','Kentucky',40514,'859-474-3924'),
  (35,NULL,NULL,'The UPS Store','1890 Star Shoot Pkwy #170','Lexington','Kentucky',40509,'859-920-9194'),
  (36,'Henry','Williams',NULL,'2152 Carolina Ln','Lexington','Kentucky',40513,'859-733-7354'),
  (37,NULL,NULL,'Lilli & Loo','785 Lexington Avenue','New York','New York',10065,'212-600-9065'),
  (38,'Ella','Brown',NULL,'2222 Frederick Douglass Blvd','New York','New York',10026,'212-589-5828'),
  (39,NULL,NULL,'Wendy\'s','2296 Thunderstick Dr','Lexington','Kentucky',40505,'859-922-1143'),
  (40,'Liam','Clark',NULL,'620 Cooper Dr','Lexington','Kentucky',40502,'859-440-1904'),
	-- TEAM 1
  (41,'James','Hill',NULL,'685 S Limestone Apt 203','Lexington','Kentucky','40508','859-656-7612'),
  (42,'Andrew','Montgomery',NULL,'629 Nakomi Drive','Lexington','Kentucky','40503','555-123-4567'),
  (43,'Victor','Cerzyk',NULL,'1617 Kensington Way','Lexington','Kentucky','40513','555-987-6543'),
  (44,'Dean','Ween',NULL,'3824 Kittiwake Dr','Lexington','Kentucky','40517','555-789-0123'),
  (45,'Mickey','Melchiondo',NULL,'103 Edison Drive','Lexington','Kentucky','40503','555-234-5678'),
  (46,'Aaron','Freeman Sr.',NULL,'2029 Oleander Drive','Lexington','Kentucky','40504','555-876-5332'),
  (47,'Milton','Plumbottom',NULL,'3527 Brookview Dr.','Lexington','Kentucky','40517','555-345-6689'),
  (48,'Po','Wei',NULL,'100 W 57th St #12E','New York','New York','10019','555-765-4121'),
  (49,'Frankie','Bauls',NULL,'70 Oceana Drive W #1D','Brooklyn','New York','11235','555-456-7890'),
  (50,'Jerry','Garcia',NULL,'215 E 24th St APT 110','New York','New York','10010','555-654-3210'),
  (51,'Nate','Newton',NULL,'155 E 79th St #9','New York','New York','10075','555-210-9676'),
  (52,'Chris','Barland',NULL,'2239 Troy Ave APT 6C','Brooklyn','New York','11234','555-543-2129'),
  (53,'Harry','DuBois',NULL,'6108 Abrams Rd APT 101','Dallas','Texas','75231','555-890-1234'),
  (54,'Jimmy','Wilson',NULL,'6600 Eastridge Dr APT 117','Dallas','Texas','75231','555-321-0987'),
  (55,'Annie','Hall',NULL,'3030 McKinney Ave APT 1104','Dallas','Texas','75204','555-678-9012'),
  (56,NULL,NULL,'Wildcat Pantry','440 Hilltop Ave','Lexington','Kentucky','40508','555-432-1198'),
  (57,NULL,NULL,'Awesome Inc Business','348 E Main St','Lexington','Kentucky','40507','555-109-8765'),
  (58,NULL,NULL,'Urban Outfitters','Victorian Sq, 401 W Main St','Lexington','Kentucky','40507','555-876-5532'),
  (59,NULL,NULL,'Pies & Pints','401 W Main St Suite 106','Lexington','Kentucky','40507','555-567-4221'),
  (60,NULL,NULL,'Pasta Garage Italian Café','962 Delaware Ave','Lexington','Kentucky','40505','555-234-9776'),
  (61,NULL,NULL,'Sorella Gelateria','591 W Short St','Lexington','Kentucky','40507','555-345-2119'),
  (62,NULL,NULL,'Agave & Rye','123 N Broadway','Lexington','Kentucky','40507','555-678-5432'),
  (63,NULL,NULL,'Chaotic Good','545 South Broadway Suite 160','Lexington','Kentucky','40508','555-987-1298'),
  (64,NULL,NULL,'Crank & Boom Craft Ice Cream','1210 Manchester St','Lexington','Kentucky','40504','555-876-4421'),
  (65,NULL,NULL,'Kroger','704 Euclid Avenue','Lexington','Kentucky','40502','555-123-2111'),
  (66,NULL,NULL,'Target','500 S Upper Street STE 110','Lexington','Kentucky','40508','555-543-6789'),
  (67,NULL,NULL,'Fox Pest Control','2532 Regency Rd Suite #105','Lexington','Kentucky','40503','555-890-4321'),
  (68,NULL,NULL,'Amazon Corporate HeadQuarters','410 Terry Ave N','Seattle','WA','98109','555-321-9876'),
  (69,NULL,NULL,'PacSun','3401 Nicholasville Rd','Lexington','Kentucky','40503','555-678-2109'),
  (70,NULL,NULL,'Walmart','500 W New Circle Rd','Lexington','Kentucky','40511','555-432-1098'),
	-- TEAM 18
  (71,'John','Doe',NULL,'455 10th Ave','New York','New York','10018','718-889-0558'),
  (72,'Jessica','Robinson',NULL,'490 Second Avenue, Apt 09A','New York','New York','10016','646-460-2689'),
  (73,'Antony','Miller',NULL,'100 W 31st St','New York','New York','10001','646-423-9978'),
  (74,'Malcolm','McMillan',NULL,'600 W 58th St','New York','New York','10019','212-793-5196'),
  (75,'Christa','George',NULL,'95 Wall St','New York','New York','10005','656-430-1230'),
  (76,'Cassie','Stevens',NULL,'329 S. Martin Luther King Blvd, Boyd Hall','Lexington','Kentucky','40526','606-813-1678'),
  (77,'Dawson','Jones',NULL,'6403 Del Norte Ln','Dallas','Texas','75225','606-813-3268'),
  (78,'Hope','Smith',NULL,'3608 Hopetown Rd','Dallas','Texas','75229','606-813-1535'),
  (79,'Allie','Phillips',NULL,'2209 Sweetberry Ct','Lexington','Kentucky','40513','606-231-0417'),
  (80,'Loch','Ness',NULL,'558 Jonelle Ave','Dallas','Texas','75217','859-447-7062'),
  (81,'Rack','Room Shoes',NULL,'3401 Nicholasville Rd, Spc D-406 Fayette Mall','Lexington','Kentucky','40503','855-466-7467'),
  (82,NULL,NULL,'H&M','3401 Nicholasville Rd, Fayette Mall','Lexington','Kentucky','40503','855-466-7467'),
  (83,NULL,NULL,'FYE','3401 Nicholasville Rd, Fayette Mall','Lexington','Kentucky','40503','859-273-1685'),
  (84,NULL,NULL,'Auntie Anne\'s','3615 Nicholasville Rd, Fayette Mall','Lexington','Kentucky','40503',NULL),
  (85,NULL,NULL,'Pediatric and Adolescent','3050 Harrodsburg Rd Ste 100','Lexington','Kentucky','40503','859-277-6102'),
  (86,NULL,NULL,'The UPS Store','838 E High St','Lexington','Kentucky','40502','859-268-6231'),
  (87,NULL,NULL,'Target','131 West Reynolds Rd','Lexington','Kentucky','40503','859-273-9403'),
  (88,NULL,NULL,'University of Kentucky Bookstore','160 Avenue of Champions','Lexington','Kentucky','40526','859-257-0236'),
  (89,NULL,NULL,'Buffalo Wild Wings','1080 S Broadway Ste 104','Lexington','Kentucky','40504','859-233-2999'),
  (90,NULL,NULL,'Best Buy','3220 Nicholasville Rd Ste 170','Lexington','Kentucky','40503','859-272-0024'),
  (91,NULL,NULL,'Nintendo Store','10 Rockefeller Plaza','New York','New York','10020','646-459-0800'),
  (92,NULL,NULL,'Black Iron Burger','245 W 38th St','New York','New York','10018','646-476-3116'),
  (93,NULL,NULL,'Texas Instruments Incorporated - Headquarters','12500 TI Blvd','Dallas','Texas','75243','855-226-3113'),
  (94,NULL,NULL,'Chewy','1950 N Stemmons Fwy','Dallas','Texas','75207','800-672-4399'),
  (95,NULL,NULL,'Froggie\'s 5 & 10 Toy Store','3207 Knox St','Dallas','Texas','75205','214-522-5867'),
  (96,NULL,NULL,'Camp','9830 N Central Expy','Dallas','Texas','75231','214-612-0451'),
  (97,NULL,NULL,'Wild Bill\'s Western Store','311 N Market St Ste 101','Dallas','Texas','75202','214-954-1050'),
  (98,NULL,NULL,'Rezdora','27 E 20th St','New York','New York','10003','646-692-9090'),
  (99,NULL,NULL,'Bengal Tiger','58 W 56th St','New York','New York','10019','212-265-2703'),
  (100,NULL,NULL,'Apple Fifth Avenue','767 5th Ave','New York','New York','10153','212-336-1440');
/*!40000 ALTER TABLE `buyers_sellers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `receipts`
--

DROP TABLE IF EXISTS `receipts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `receipts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `buyer_id` int(11) DEFAULT NULL,
  `seller_id` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `total_sale_price` float DEFAULT NULL,
  `num_items_sold` int(11) DEFAULT NULL,
  `item_type` varchar(45) DEFAULT NULL,
  `photo` blob,
  PRIMARY KEY (`id`),
  KEY `buyer` (`buyer_id`),
  KEY `seller` (`seller_id`),
  CONSTRAINT `buyer` FOREIGN KEY (`buyer_id`) REFERENCES `buyers_sellers` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `seller` FOREIGN KEY (`seller_id`) REFERENCES `buyers_sellers` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `receipts`
--

LOCK TABLES `receipts` WRITE;
/*!40000 ALTER TABLE `receipts` DISABLE KEYS */;
INSERT INTO `receipts` VALUES
  (1,11,12,'2023-09-23',11.49,2,'Food',NULL),
  (2,13,14,'2023-02-09',223.87,40,'Home Goods',NULL),
  (3,15,16,'2023-09-13',27.75,4,'Food',NULL),
  (4,17,18,'2023-09-04',9.32,1,'Food',NULL),
  (5,19,20,'2023-09-25',26.75,1,'Train Ticket',NULL),
  (6,21,22,'2023-09-16',28.62,21,'Home Goods',NULL),
  (7,23,24,'2023-09-27',9.21,1,'Food',NULL),
  (8,25,26,'2023-09-14',19.95,5,'Home Goods',NULL),
  (9,27,28,'2023-09-19',120.79,3,'Home Goods',NULL),
  (10,29,30,'2023-09-01',8.68,1,'Food',NULL),
  (11,31,32,'2023-09-19',2.89,1,'Food',NULL),
  (12,33,34,'2023-09-12',46.72,3,'Food',NULL),
  (13,35,36,'2023-09-19',26.42,1,'Mailing',NULL),
  (14,37,38,'2023-09-23',83.62,4,'Food',NULL),
  (15,39,40,'2023-09-09',9.85,1,'Food',NULL),
  (16,69,47,'2023-03-20',266.33,8,NULL,NULL),
  (17,59,44,'2023-01-25',34.21,2,NULL,NULL),
  (18,62,42,'2023-04-30',24.22,1,NULL,NULL),
  (19,70,41,'2022-09-27',131.43,6,NULL,NULL),
  (20,68,48,'2020-04-16',18.19,2,NULL,NULL),
  (21,63,53,'2023-08-28',34.01,3,NULL,NULL),
  (22,57,50,'2023-09-11',45.63,2,NULL,NULL),
  (23,65,54,'2023-10-02',13.17,1,NULL,NULL),
  (24,61,52,'2023-09-02',8.96,1,NULL,NULL),
  (25,56,43,'2023-08-14',56.77,3,NULL,NULL),
  (26,66,45,'2023-09-16',15.10,6,NULL,NULL),
  (27,64,51,'2023-09-15',5.28,1,NULL,NULL),
  (28,60,49,'2023-09-16',10.18,1,NULL,NULL),
  (29,67,55,'2023-09-30',21.19,3,NULL,NULL),
  (30,58,46,'2023-10-01',23.72,8,NULL,NULL),
  (31,79,81,'2023-09-16',41.11,2,'Shoes',NULL),
  (32,76,82,'2023-09-16',37.81,3,'Clothes',NULL),
  (33,76,83,'2023-09-16',37.81,3,'Clothes',NULL),
  (34,76,84,'2023-09-16',10.63,2,'Pretzels',NULL),
  (35,61,85,'2023-09-29',26.00,1,'Copay',NULL),
  (36,69,86,'2023-10-11',0.00,4,'Item Return',NULL),
  (37,68,87,'2023-09-16',7.83,1,'Snacks',NULL),
  (38,76,88,'2023-09-08',53.92,7,'Books',NULL),
  (39,67,89,'2023-06-08',24.35,1,'Wings',NULL),
  (40,74,90,'2023-09-15',790.23,4,'Xbox + Accessories',NULL),
  (41,64,91,'2023-08-12',103.21,2,'Video Games',NULL),
  (42,75,92,'2023-06-30',29.10,2,'Burger',NULL),
  (43,78,95,'2023-07-03',120.83,10,'Toys',NULL),
  (44,71,98,'2023-05-30',31.24,2,'Italian Food',NULL),
  (45,73,99,'2023-08-11',63.12,4,'Indian Food',NULL);
/*!40000 ALTER TABLE `receipts` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-27 21:42:34
