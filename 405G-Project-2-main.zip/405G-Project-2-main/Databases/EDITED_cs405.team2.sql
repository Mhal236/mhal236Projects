-- MySQL dump 10.13  Distrib 8.0.35, for Linux (x86_64)
--
-- Host: mysql    Database: jba231
-- ------------------------------------------------------
-- Server version	5.5.5-10.1.48-MariaDB-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `jba231`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `jba231` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;

USE `jba231`;

--
-- Table structure for table `buyers_sellers`
--

DROP TABLE IF EXISTS `buyers_sellers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `buyers_sellers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(45) DEFAULT NULL,
  `last_name` varchar(45) DEFAULT NULL,
  `business_name` varchar(45) DEFAULT NULL,
  `address` varchar(45) DEFAULT NULL,
  `city` varchar(45) DEFAULT NULL,
  `state` varchar(45) DEFAULT NULL,
  `zipcode` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `buyers_sellers`
--

LOCK TABLES `buyers_sellers` WRITE;
/*!40000 ALTER TABLE `buyers_sellers` DISABLE KEYS */;
INSERT INTO `buyers_sellers` VALUES
  (1,'Ray','Hyatt',NULL,'300 Rose Street Room 102 Hardymon Building','Lexington','Kentucky',40506),
  (2,'Ray','Hyatt',NULL,'301 Hilltop Avenue, Room 102','Lexington','Kentucky',40506),
  (3,'John','Wick',NULL,'82 Beaver St Room 1301','New York','New York',10005),
  (4,'Tony','Stark',NULL,'200 Park Avenue Penthouse','New York','New York',10001),
  (5,'Stephen','Strange',NULL,'117A Bleecker Street','New York','New York',10001),
  (6,'Bob','Smith',NULL,'200 Park Avenue Apartment 221','New York','New York',10001),
  (7,'Bowman','Wildcat',NULL,'#1 Avenue of Champions','Lexington','Kentucky',40506),
  (8,'Bob','Smith',NULL,'200 Park Avenue','Lexington','Kentucky',40507),
  (9,'Bob','Porter','Intech','1 Dead End Row Room 200','Dallas','Texas',12347),
  (10,'Bob','Sydell','Intech','1 Dead End Row Room 200','Dallas','Texas',12347),
  (11,NULL,NULL,'Honey Joe\'s','5 Broad St Unit 2B','Stamford','Connecticut',6901),
  (12,'Alex','Savinsky',NULL,'112 Revonah Ave','Stamford','Connecticut',6905),
  (13,NULL,NULL,'Lowe\'s','2300 Grey Lag Way','Lexington','Kentucky',40509),
  (14,'Richard','Dunn',NULL,'662 Bluegrass Park Dr','Lexington','Kentucky',40508),
  (15,NULL,NULL,'Jersey Mike\'s','2200 War Admiral Way','Lexington','Kentucky',40509),
  (16,'Anthony','Wilson',NULL,'1153 Mt Rushmore Way','Lexington','Kentucky',40515),
  (17,NULL,NULL,'Cook Out','855 S Broadway','Lexington','Kentucky',40504),
  (18,'Louis','Miller',NULL,'219 Londonderry Dr','Lexington','Kentucky',40504),
  (19,NULL,NULL,'Metro-North Railroad','420 Lexington Avenue 5th Floor','New York','New York',10170),
  (20,'Justin','Barlow',NULL,'122 E 93rd St','New York','New York',10128),
  (21,NULL,NULL,'Party City','2172 Sir Barton Way','Lexington','Kentucky',40509),
  (22,'James','Anderson',NULL,'2480 Paris Pike','Lexington','Kentucky',40511),
  (23,NULL,NULL,'McDonald\'s','2271 Elkhorn Road','Lexington','Kentucky',40505),
  (24,'Adam','Harris',NULL,'2703 Barbados Ln','Lexington','Kentucky',40509),
  (25,NULL,NULL,'Walmart','2350 Grey Lag Way','Lexington','Kentucky',40509),
  (26,'Charles','Lee',NULL,'501 Ridge Rd','Lexington','Kentucky',40503),
  (27,NULL,NULL,'Costco','1500 Fitzgerald Court','Lexington','Kentucky',40509),
  (28,'Daniel','Johnson',NULL,'3601 Brookewind Way','Lexington','Kentucky',40515),
  (29,NULL,NULL,'Culver\'s','2161 Paul Jones Way','Lexington','Kentucky',40509),
  (30,'Sam','Davis',NULL,'1325 Wakehurst Ct','Lexington','Kentucky',40509),
  (31,NULL,NULL,'Meijer','2155 Paul Jones Way, Suite 100','Lexington','Kentucky',40509),
  (32,'Lucas','Campbell',NULL,'408 Lenney Ct','Lexington','Kentucky',40517),
  (33,NULL,NULL,'Olive Garden','3094 Helmsdale Place','Lexington','Kentucky',40509),
  (34,'Ethan','Cooper',NULL,'325 Silverbell Trace','Lexington','Kentucky',40514),
  (35,NULL,NULL,'The UPS Store','1890 Star Shoot Pkwy #170','Lexington','Kentucky',40509),
  (36,'Henry','Williams',NULL,'2152 Carolina Ln','Lexington','Kentucky',40513),
  (37,NULL,NULL,'Lilli & Loo','785 Lexington Avenue','New York','New York',10065),
  (38,'Ella','Brown',NULL,'2222 Frederick Douglass Blvd','New York','New York',10026),
  (39,NULL,NULL,'Wendy\'s','2296 Thunderstick Dr','Lexington','Kentucky',40505),
  (40,'Liam','Clark',NULL,'620 Cooper Dr','Lexington','Kentucky',40502);
/*!40000 ALTER TABLE `buyers_sellers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `receipts`
--

DROP TABLE IF EXISTS `receipts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `receipts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `buyer_id` int(11) DEFAULT NULL,
  `seller_id` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `total_sale_price` float DEFAULT NULL,
  `num_items_sold` int(11) DEFAULT NULL,
  `item_type` varchar(45) DEFAULT NULL,
  `photo` blob,
  PRIMARY KEY (`id`),
  KEY `buyer` (`buyer_id`),
  KEY `seller` (`seller_id`),
  CONSTRAINT `buyer` FOREIGN KEY (`buyer_id`) REFERENCES `buyers_sellers` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `seller` FOREIGN KEY (`seller_id`) REFERENCES `buyers_sellers` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `receipts`
--

LOCK TABLES `receipts` WRITE;
/*!40000 ALTER TABLE `receipts` DISABLE KEYS */;
INSERT INTO `receipts` VALUES
  (1,11,12,'2023-09-23',11.49,2,'Food',NULL),
  (2,13,14,'2023-02-09',223.87,40,'Home Goods',NULL),
  (3,15,16,'2023-09-13',27.75,4,'Food',NULL),
  (4,17,18,'2023-09-04',9.32,1,'Food',NULL),
  (5,19,20,'2023-09-25',26.75,1,'Train Ticket',NULL),
  (6,21,22,'2023-09-16',28.62,21,'Home Goods',NULL),
  (7,23,24,'2023-09-27',9.21,1,'Food',NULL),
  (8,25,26,'2023-09-14',19.95,5,'Home Goods',NULL),
  (9,27,28,'2023-09-19',120.79,3,'Home Goods',NULL),
  (10,29,30,'2023-09-01',8.68,1,'Food',NULL),
  (11,31,32,'2023-09-19',2.89,1,'Food',NULL),
  (12,33,34,'2023-09-12',46.72,3,'Food',NULL),
  (13,35,36,'2023-09-19',26.42,1,'Mailing',NULL),
  (14,37,38,'2023-09-23',83.62,4,'Food',NULL),
  (15,39,40,'2023-09-09',9.85,1,'Food',NULL);
/*!40000 ALTER TABLE `receipts` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-27 21:42:34
