-- MySQL dump 10.13  Distrib 8.0.35, for Linux (x86_64)
--
-- Host: mysql    Database: jku230
-- ------------------------------------------------------
-- Server version	5.5.5-10.1.48-MariaDB-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Addresses`
--

DROP TABLE IF EXISTS `Addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Addresses` (
  `addressID` int(11) NOT NULL AUTO_INCREMENT,
  `Type` text,
  `Name` text NOT NULL,
  `Address1` text NOT NULL,
  `City` text NOT NULL,
  `State` text NOT NULL,
  `PostalCode` char(5) NOT NULL,
  PRIMARY KEY (`addressID`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Addresses`
--

LOCK TABLES `Addresses` WRITE;
/*!40000 ALTER TABLE `Addresses` DISABLE KEYS */;
INSERT INTO `Addresses` VALUES
  (1,'Consumer','Mr. Ray L. Hyatt Jr.','300 Rose Street Room 102 Hardymon Building','Lexington','Kentucky','40506'),
  (2,'Consumer','Mr. Ray L. Hyatt Jr.','301 Hilltop Avenue, Room 102','Lexington','Ky','40506'),
  (3,'Consumer','John Wick','82 Beaver St Room 1301','New York','New York','10005'),
  (4,'Consumer','Tony Stark','200 Park Avenue Penthouse','New York','New York','10001'),
  (5,'Consumer','Dr. Stephen Strange','117A Bleecker Street','New York','New York','10001'),
  (6,'Consumer','Bob C. Smith','200 Park Avenue Apartment 221','New York','NY','10001'),
  (7,'Consumer','Bowman F. Wildcat','#1 Avenue of Champions','Lexington','Ky','40506'),
  (8,'Consumer','Bob C. Smith','200 Park Avenue','Lexington','KY','40507'),
  (9,'Consumer','Bob Porter c/o Intech','1 Dead End Row Room 200','Dallas','Texas','12347'),
  (10,'Consumer','Mr. Bob Sydell c/o Intech','1 Dead End Row Room 200','Dallas','Texas','12347'),
  (11,'Consumer','James Hill','685 S Limestone Apt 203','Lexington','KY','40508'),
  (12,'Consumer','Andrew Montgomery','629 Nakomi Drive','Lexington','KY','40503'),
  (13,'Consumer','Victor Cerzyk','1617 Kensington Way','Lexington','KY','40513'),
  (14,'Consumer','Dean Ween','3824 Kittiwake Dr','Lexington','KY','40517'),
  (15,'Consumer','Mickey Melchiondo','103 Edison Drive','Lexington','KY','40503'),
  (16,'Consumer','Aaron Freeman Sr.','2029 Oleander Drive','Lexington','KY','40504'),
  (17,'Consumer','Milton Plumbottom','3527 Brookview Dr.','Lexington','KY','40517'),
  (18,'Consumer','Po Wei','100 W 57th St #12E','New York','New York','10019'),
  (19,'Consumer','Frankie Bauls','70 Oceana Drive W #1D','Brooklyn','New York','11235'),
  (20,'Consumer','Jerry Garcia','215 E 24th St APT 110','New York','NY','10010'),
  (21,'Consumer','Nate Newton','155 E 79th St #9','New York','New York','10075'),
  (22,'Consumer','Chris Barland','2239 Troy Ave APT 6C','Brooklyn','New York','11234'),
  (23,'Consumer','Harry DuBois','6108 Abrams Rd APT 101','Dallas','Texas','75231'),
  (24,'Consumer','Jimmy Wilson','6600 Eastridge Dr APT 117','Dallas','Texas','75231'),
  (25,'Consumer','Annie Hall','3030 McKinney Ave APT 1104','Dallas','Texas','75204'),
  (26,'Business','Wildcat Pantry','440 Hilltop Ave','Lexington','KY','40508'),
  (27,'Business','Awesome Inc Business','348 E Main St','Lexington','KY','40507'),
  (28,'Business','Urban Outfitters','Victorian Sq, 401 W Main St','Lexington','KY','40507'),
  (29,'Business','Pies & Pints','401 W Main St Suite 106','Lexington','KY','40507'),
  (30,'Business','Pasta Garage Italian Café','962 Delaware Ave','Lexington','KY','40505'),
  (31,'Business','Sorella Gelateria','591 W Short St','Lexington','KY','40507'),
  (32,'Business','Agave & Rye','123 N Broadway','Lexington','KY','40507'),
  (33,'Business','Chaotic Good','545 South Broadway Suite 160','Lexington','KY','40508'),
  (34,'Business','Crank & Boom Craft Ice Cream','1210 Manchester St','Lexington','KY','40504'),
  (35,'Business','Kroger','704 Euclid Avenue','Lexington','KY','40502'),
  (36,'Business','Target','500 S Upper Street STE 110','Lexington','KY','40508'),
  (37,'Business','Urban Outfitters','Victorian Sq, 401 W Main St ','Lexington','Kentucky','40507'),
  (38,'Business','Amazon Corporate HeadQuarters','410 Terry Ave N','Seattle','WA','98109'),
  (39,'Business','PacSun','3401 Nicholasville Rd','Lexington','Kentucky','40503'),
  (40,'Business','Walmart','500 W New Circle Rd','Lexington','KY','40511');
/*!40000 ALTER TABLE `Addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PhoneNumbers`
--

DROP TABLE IF EXISTS `PhoneNumbers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PhoneNumbers` (
  `PhoneNumberID` int(11) NOT NULL AUTO_INCREMENT,
  `PersonID` int(11) NOT NULL,
  `PhoneNumber` text,
  PRIMARY KEY (`PhoneNumberID`),
  KEY `PersonID` (`PersonID`),
  CONSTRAINT `PhoneNumbers_ibfk_1` FOREIGN KEY (`PersonID`) REFERENCES `Addresses` (`addressID`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PhoneNumbers`
--

LOCK TABLES `PhoneNumbers` WRITE;
/*!40000 ALTER TABLE `PhoneNumbers` DISABLE KEYS */;
INSERT INTO `PhoneNumbers` VALUES
  (1,1,'859-656-7612'),
  (2,11,'555-123-4567'),
  (3,12,'555-987-6543'),
  (4,13,'555-789-0123'),
  (5,14,'555-234-5678'),
  (6,15,'555-876-5432'),
  (7,16,'555-345-6789'),
  (8,17,'555-765-4321'),
  (9,18,'555-456-7890'),
  (10,19,'555-654-3210'),
  (11,20,'555-210-9876'),
  (12,21,'555-543-2109'),
  (13,22,'555-890-1234'),
  (14,23,'555-321-0987'),
  (15,24,'555-678-9012'),
  (16,25,'555-432-1098'),
  (17,26,'555-109-8765'),
  (18,27,'555-876-5432'),
  (19,28,'555-567-4321'),
  (20,29,'555-234-9876'),
  (21,30,'555-345-2109'),
  (22,31,'555-678-5432'),
  (23,32,'555-987-1098'),
  (24,33,'555-876-4321'),
  (25,34,'555-123-2109'),
  (26,35,'555-543-6789'),
  (27,36,'555-890-4321'),
  (28,37,'555-321-9876'),
  (29,38,'555-678-2109'),
  (30,39,'555-432-1098'),
  (31,40,'555-210-9876');
/*!40000 ALTER TABLE `PhoneNumbers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Receipt`
--

DROP TABLE IF EXISTS `Receipt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Receipt` (
  `ReceiptID` int(11) NOT NULL AUTO_INCREMENT,
  `LocationBusinessID` int(11) DEFAULT NULL,
  `LocationConsumerID` int(11) DEFAULT NULL,
  `Date` date DEFAULT NULL,
  `TotalSale` decimal(10,2) DEFAULT NULL,
  `NumberOfItemsSold` int(11) DEFAULT NULL,
  `TransInfo` blob,
  `HighestPrice` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`ReceiptID`),
  KEY `LocationBusinessID` (`LocationBusinessID`),
  KEY `LocationConsumerID` (`LocationConsumerID`),
  CONSTRAINT `Receipt_ibfk_1` FOREIGN KEY (`LocationBusinessID`) REFERENCES `Addresses` (`addressID`),
  CONSTRAINT `Receipt_ibfk_2` FOREIGN KEY (`LocationConsumerID`) REFERENCES `Addresses` (`addressID`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Receipt`
--

LOCK TABLES `Receipt` WRITE;
/*!40000 ALTER TABLE `Receipt` DISABLE KEYS */;
INSERT INTO `Receipt` VALUES
  (1,39,17,'2023-03-20',266.33,8,NULL,55.50),
  (2,29,14,'2023-01-25',34.21,2,NULL,10.23),
  (3,32,12,'2023-04-30',24.22,1,NULL,5.99),
  (4,40,11,'2022-09-27',131.43,6,NULL,24.99),
  (5,38,18,'2020-04-16',18.19,2,NULL,7.99),
  (6,33,23,'2023-08-28',34.01,3,NULL,15.50),
  (7,27,20,'2023-09-11',45.63,2,NULL,15.50),
  (8,35,24,'2023-10-02',13.17,1,NULL,6.99),
  (9,31,22,'2023-09-02',8.96,1,NULL,5.79),
  (10,26,13,'2023-08-14',56.77,3,NULL,25.50),
  (11,36,15,'2023-09-16',15.10,6,NULL,8.50),
  (12,34,21,'2023-09-15',5.28,1,NULL,3.40),
  (13,30,19,'2023-09-16',10.18,1,NULL,7.35),
  (14,37,25,'2023-09-30',21.19,3,NULL,10.99),
  (15,28,16,'2023-10-01',23.72,8,NULL,12.99);
/*!40000 ALTER TABLE `Receipt` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-23 19:49:24
