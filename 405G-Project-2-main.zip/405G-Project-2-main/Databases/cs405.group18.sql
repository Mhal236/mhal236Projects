-- MySQL dump 10.13  Distrib 8.0.35, for Linux (x86_64)
--
-- Host: mysql    Database: astr229
-- ------------------------------------------------------
-- Server version	5.5.5-10.1.48-MariaDB-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `astr229`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `astr229` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;

USE `astr229`;

--
-- Table structure for table `Addresses`
--

DROP TABLE IF EXISTS `Addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Addresses` (
  `AddressID` int(11) NOT NULL AUTO_INCREMENT,
  `Recipient` varchar(200) DEFAULT NULL,
  `DeliveryAddress` varchar(200) DEFAULT NULL,
  `City` varchar(50) DEFAULT NULL,
  `State` varchar(2) DEFAULT NULL,
  `ZipCode` char(10) DEFAULT NULL,
  `Extra` blob,
  `PhoneNumber` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`AddressID`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Addresses`
--

LOCK TABLES `Addresses` WRITE;
/*!40000 ALTER TABLE `Addresses` DISABLE KEYS */;
INSERT INTO `Addresses` VALUES (1,'Mr. Ray L. Hyatt Jr.','300 Rose Street Room 102 Hardymon Building','Lexington','KY','40506',NULL,NULL),(2,'Mr. Ray L. Hyatt Jr.','301 Hilltop Avenue, Room 102','Lexington','KY','40506',NULL,NULL),(3,'John Wick','82 Beaver St Room 1301','New York','NY','10005',NULL,'555-555-5555'),(4,'Tony Stark','200 Park Avenue Penthouse','New York','NY','10001',NULL,'555-555-3142'),(5,'Dr. Stephen Strange','117A Bleecker Street','New York','NY','10001',NULL,'(555)555-4321'),(6,'Bob C. Smith','200 Park Avenue Apartment 221','New York','NY','10001',NULL,NULL),(7,'Bowman F. Wildcat','#1 Avenue of Champions','Lexington','KY','40506',NULL,NULL),(8,'Bob C. Smith','200 Park Avenue','Lexington','KY','40507',NULL,NULL),(9,'Bob Porter c/o Intech','1 Dead End Row Room 200','Dallas','TX','12347',NULL,NULL),(10,'Mr. Bob Sydell c/o Intech','1 Dead End Row Room 200','Dallas','TX','12347',NULL,NULL),(11,'John Doe','455 10th Ave','New York','NY','10018',NULL,'718-889-0558'),(12,'Jessica Robinson','490 Second Avenue, Apt 09A','New York','NY','10016',NULL,'646-460-2689'),(13,'Antony Miller','100 W 31st St','New York','NY','10001',NULL,'646-423-9978'),(14,'Malcolm McMillan','600 W 58th St','New York','NY','10019',NULL,'212-793-5196'),(15,'Christa George','95 Wall St','New York','NY','10005',NULL,'656-430-1230'),(16,'Cassie Stevens','329 S. Martin Luther King Blvd, Boyd Hall','Lexington','KY','40526',NULL,'606-813-1678'),(17,'Dawson Jones','6403 Del Norte Ln','Dallas','TX','75225',NULL,'606-813-3268'),(18,'Hope Smith','3608 Hopetown Rd','Dallas','TX','75229',NULL,'606-813-1535'),(19,'Allie Phillips','2209 Sweetberry Ct','Lexington','KY','40513',NULL,'606-231-0417'),(20,'Loch Ness','558 Jonelle Ave','Dallas','TX','75217',NULL,'859-447-7062'),(21,'Rack Room Shoes','3401 Nicholasville Rd, Spc D-406 Fayette Mall','Lexington','KY','40503',NULL,'855-466-7467'),(22,'H&M','3401 Nicholasville Rd, Fayette Mall','Lexington','KY','40503',NULL,'855-466-7467'),(23,'FYE','3401 Nicholasville Rd, Fayette Mall','Lexington','KY','40503',NULL,'859-273-1685'),(24,'Auntie Anne\'s','3615 Nicholasville Rd, Fayette Mall','Lexington','KY','40503',NULL,NULL),(25,'Pediatric and Adolescent','3050 Harrodsburg Rd Ste 100','Lexington','KY','40503',NULL,'859-277-6102'),(26,'The UPS Store','838 E High St','Lexington','KY','40502-2107',NULL,'859-268-6231'),(27,'Target','131 West Reynolds Rd','Lexington','KY','40503',NULL,'859-273-9403'),(28,'University of Kentucky Bookstore','160 Avenue of Champions','Lexington','KY','40526',NULL,'859-257-0236'),(29,'Buffalo Wild Wings','1080 S Broadway Ste 104','Lexington','KY','40504',NULL,'859-233-2999'),(30,'Best Buy','3220 Nicholasville Rd Ste 170','Lexington','KY','40503',NULL,'859-272-0024'),(31,'Nintendo Store','10 Rockefeller Plaza','New York','NY','10020',NULL,'646-459-0800'),(32,'Black Iron Burger','245 W 38th St','New York','NY','10018',NULL,'646-476-3116'),(33,'Texas Instruments Incorporated - Headquarters','12500 TI Blvd','Dallas','TX','75243',NULL,'855-226-3113'),(34,'Chewy','1950 N Stemmons Fwy','Dallas','TX','75207',NULL,'800-672-4399'),(35,'Froggie\'s 5 & 10 Toy Store','3207 Knox St','Dallas','TX','75205',NULL,'214-522-5867'),(36,'Camp','9830 N Central Expy','Dallas','TX','75231',NULL,'214-612-0451'),(37,'Wild Bill\'s Western Store','311 N Market St Ste 101','Dallas','TX','75202',NULL,'214-954-1050'),(38,'Rezdora','27 E 20th St','New York','NY','10003',NULL,'646-692-9090'),(39,'Bengal Tiger','58 W 56th St','New York','NY','10019',NULL,'212-265-2703'),(40,'Apple Fifth Avenue','767 5th Ave','New York','NY','10153',NULL,'212-336-1440');
/*!40000 ALTER TABLE `Addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Receipts`
--

DROP TABLE IF EXISTS `Receipts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Receipts` (
  `ReceiptID` int(11) NOT NULL AUTO_INCREMENT,
  `CustomerID` int(11) DEFAULT NULL,
  `VendorID` int(11) DEFAULT NULL,
  `Name` varchar(200) DEFAULT NULL,
  `Date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Total` decimal(30,2) NOT NULL,
  `NumItems` int(11) NOT NULL,
  `Extra` blob,
  `HighestPrice` decimal(30,2) DEFAULT NULL,
  `LowestPrice` decimal(30,2) DEFAULT NULL,
  PRIMARY KEY (`ReceiptID`),
  KEY `CustomerID` (`CustomerID`),
  KEY `VendorID` (`VendorID`),
  CONSTRAINT `Receipts_ibfk_1` FOREIGN KEY (`CustomerID`) REFERENCES `Addresses` (`AddressID`),
  CONSTRAINT `Receipts_ibfk_2` FOREIGN KEY (`VendorID`) REFERENCES `Addresses` (`AddressID`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Receipts`
--

LOCK TABLES `Receipts` WRITE;
/*!40000 ALTER TABLE `Receipts` DISABLE KEYS */;
INSERT INTO `Receipts` VALUES (1,19,21,'Shoes','2023-09-16 12:04:39',41.11,2,NULL,32.11,9.00),(2,16,22,'Clothes','2023-09-16 18:06:25',37.81,3,NULL,17.20,10.61),(3,16,23,'Clothes','2023-09-16 13:55:10',37.81,3,NULL,32.11,2.99),(4,16,24,'Pretzels','2023-09-16 12:10:03',10.63,2,NULL,9.99,0.64),(5,1,25,'Copay','2023-09-29 11:05:04',26.00,1,NULL,26.00,26.00),(6,9,26,'Item Return','2023-10-11 14:08:40',0.00,4,NULL,0.00,0.00),(7,8,27,'Snacks','2023-09-16 20:10:01',7.83,1,NULL,7.83,7.83),(8,16,28,'Books','2023-09-08 17:15:10',53.92,7,NULL,10.99,2.49),(9,7,29,'Wings','2023-06-08 13:35:16',24.35,1,NULL,24.35,24.35),(10,14,30,'Xbox + Accessories','2023-09-15 16:30:30',790.23,4,NULL,505.11,50.32),(11,4,31,'Video Games','2023-08-12 15:20:04',103.21,2,NULL,73.12,30.09),(12,15,32,'Burger','2023-06-30 14:05:08',29.10,2,NULL,20.99,8.11),(13,18,35,'Toys','2023-07-03 10:01:03',120.83,10,NULL,11.99,5.34),(14,11,38,'Italian Food','2023-05-30 17:50:03',31.24,2,NULL,22.10,9.14),(15,13,39,'Indian Food','2023-08-11 14:01:39',63.12,4,NULL,25.12,8.49);
/*!40000 ALTER TABLE `Receipts` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-28 14:12:58
