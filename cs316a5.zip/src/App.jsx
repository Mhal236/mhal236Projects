import {useState} from 'react'
import {Accordion, Button, Checkbox, Container, Grid, Icon, Input, Label, Segment} from 'semantic-ui-react'
import 'semantic-ui-css/semantic.min.css'
import './App.css'

function App() {
    const [APIURL, setAPIURL] = useState("http://cs.uky.edu/~soward/cs316a5.php");
    // const [APIURL, setAPIURL] = useState("http://localhost/cs316a4.php");
    const [songs, setSongs] = useState();
    const [playlists, setPlaylists] = useState();
    const [checkedSongs, setCheckedSongs] = useState([]);
    const [activeIndex, setActiveIndex] = useState()
    const [name, setName] = useState("")

    async function loadSongs() {
        await fetch(APIURL + "/songs", {
            method: "GET"
        }).then(async (response) => {
            if (response.status === 404 || response.status === 500) {
                alert(`From Server: ${response.status}: ${response.statusText} `);
            } else {
                const result = await response.json();
                setSongs(result.songs);
            }
        }).catch((error) => {
            alert(`Error Loading Songs: ${error}`);
            console.log(`Error Loading Songs: ${error}`);
            console.log(error);
        });
    }

    async function loadPlaylists() {
        await fetch(APIURL + "/playlists", {
            method: "GET"
        }).then(async (response) => {
            if (response.status === 404 || response.status === 500) {
                alert(`From Server: ${response.status}: ${response.statusText} `);
            } else {
                const result = await response.json();
                setPlaylists(result.playlists);
            }
        }).catch((error) => {
            alert(`Error Loading Songs: ${error}`);
            console.log(`Error Loading Songs: ${error}`);
            console.log(error);
        });
    }

    async function deletePlaylist(name) {
        const url = `${APIURL}/playlist/${name}`;

        try {
            const response = await fetch(url, {
                method: 'DELETE'
            });
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            } else {
                console.log(`Playlist '${name}' deleted successfully.`);
                loadPlaylists();
            }
        } catch (error) {
            // Handle any errors that occurred during the fetch
            alert(`Error Deleting Playlist: ${error}`);
            console.log(`Error Deleting Playlist: ${error}`);
        }
    }

    async function handleCreate() {
        if (name === "") {
            alert("Please enter a playlist name");
        } else if (checkedSongs.length < 1) {
            alert("Please select songs to add to the playlist");
        } else {
            const playlistData = {};
            playlistData[name] = {songs: checkedSongs}

            try {
                const response = await fetch(APIURL + '/playlists', {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(playlistData)
                });
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                } else {
                    alert(`Playlist '${name}' created successfully.`);
                    setName("")
                    setCheckedSongs([])
                    loadPlaylists();
                }
            } catch (error) {
                alert(`Error Creating Playlist: ${error}`);
                console.log(`Error Creating Playlist: ${error}`);
            }
        }
    }


    // convert time from ms to MM:SS format
    function fixTime(aTime) {
        var seconds = Math.floor(aTime / 1000);
        var minutes = Math.floor(seconds / 60);
        seconds = seconds % 60;
        var formattedMinutes = minutes < 10 ? "0" + minutes : minutes;
        var formattedSeconds = seconds < 10 ? "0" + seconds : seconds;
        return formattedMinutes + ":" + formattedSeconds;
    }

    // Set the URL we will use to access the playlist API
    function updateAPIURL(e) {
        loadSongs();
        loadPlaylists();
    }

    // Take our checked playlist action and update the actual list of songs for the new playlist
    function cbChange(songName) {
        let tempCheckedSongs = checkedSongs;
        const x = tempCheckedSongs.indexOf(songName);
        if (x < 0) {
            tempCheckedSongs.push(songName);
        } else {
            tempCheckedSongs.splice(x, 1);
        }
        setCheckedSongs(tempCheckedSongs);
        console.log(`Checked songs ${checkedSongs}`);
    }

    function SongList() {
        if (songs === undefined) {
            return (<h2> No Songs </h2>);
        }
        return (
            <>

                <Grid celled>
                    {/* Each .Row needs a unique key for React to be able to properly manage re-rendering */}
                    <Grid.Row key="headerKey453hh" color="grey">
                        <Grid.Column width="one"> <strong>-</strong> </Grid.Column>
                        <Grid.Column width="three"><strong>Song</strong></Grid.Column>
                        <Grid.Column width="three"><strong>Artist</strong></Grid.Column>
                        <Grid.Column width="three"><strong>Album</strong></Grid.Column>
                        <Grid.Column width="two"><strong>Year</strong></Grid.Column>
                        <Grid.Column width="three"><strong>Genre</strong></Grid.Column>
                        <Grid.Column width="one"><strong>Time</strong></Grid.Column>
                    </Grid.Row>

                    {/*
                    Output a row for each song you fetched,
                    matching the format of the header shown above
                    Don't forget to call ( and implement fixTime to ajust the time format )
                    */}


                    {songs && Object.keys(songs).map((el, key) => {
                        return (
                            <Grid.Row key="headerKey453hh" color="">
                                <Grid.Column width="one">
                                    <strong>
                                        <Checkbox onChange={() => {cbChange(el)}} />
                                    </strong>
                                </Grid.Column>
                                <Grid.Column width="three"><strong>{el}</strong></Grid.Column>
                                <Grid.Column width="three"><strong>{songs[el].Artist}</strong></Grid.Column>
                                <Grid.Column width="three"><strong>{songs[el].Album}</strong></Grid.Column>
                                <Grid.Column width="two"><strong>{songs[el].Year}</strong></Grid.Column>
                                <Grid.Column width="three"><strong>{songs[el].Genre}</strong></Grid.Column>
                                <Grid.Column width="one"><strong>{fixTime(songs[el].Time)}</strong></Grid.Column>
                            </Grid.Row>
                        )
                    })}


                </Grid>
            </>
        )
    }

    return (
        <Container>

            <Segment>
                <Label attached="top" color="black">URL of the API </Label>
                <Segment.Group horizontal>
                    <Segment basic size="tiny">
                        <h3>http://cs.uky.edu/~
                            <Input type="text" defaultValue="soward"
                                   style={{width: "7em"}}
                                   maxLength="8"
                                   onChange={e => setAPIURL("http://cs.uky.edu/~" + e.target.value + "/cs316a5.php")}
                            >
                            </Input>
                            /cs316a5.php</h3>

                    </Segment>
                    <Segment basic size="tiny">
                        <Button onClick={updateAPIURL}> Set URL </Button>
                    </Segment>
                </Segment.Group>
            </Segment>
            <hr/>


            <Segment>
                <Label attached="top" color="green">Available Songs</Label>
                <SongList/>
            </Segment>

            <Segment>
                <Label attached="top">Playlists</Label>

                <Segment.Group horizontal>
                    <Segment basic size="tiny">
                        <Input placeholder={"Enter Playlist Name"} style={{width: "80%", marginRight: 10}}
                               value={name} onChange={evt => {
                            setName(evt.target.value)
                        }}
                        />
                        <Button onClick={() => {
                            handleCreate()
                        }}>Create Playlist</Button>
                    </Segment>
                </Segment.Group>


                {playlists && Object.keys(playlists).map((el, key) => {
                    return (
                        <Segment.Group horizontal>
                            <Segment basic size="tiny" style={{width: "20%"}}>
                                <h3>{el}</h3>
                            </Segment>

                            <Segment basic size="tiny">
                                <Accordion>
                                    <Accordion.Title
                                        active={activeIndex === key}
                                        index={key}
                                        onClick={() => {
                                            setActiveIndex(key)
                                        }}
                                    >
                                        <Icon name='dropdown'/>
                                        {playlists[el].songs.length} Tracks
                                    </Accordion.Title>
                                    <Accordion.Content active={activeIndex === key}>
                                        {playlists[el].songs.map((song, key2) => {
                                            return <p key={key2}>{song}</p>
                                        })}
                                    </Accordion.Content>
                                </Accordion>
                            </Segment>

                            <Segment basic size="tiny">
                                <Button disabled={true}>Edit</Button>
                                <Button onClick={() => {
                                    deletePlaylist(el)
                                }}>Delete</Button>
                            </Segment>

                        </Segment.Group>
                    )
                })}

            </Segment>
        </Container>
    )
}

export default App
